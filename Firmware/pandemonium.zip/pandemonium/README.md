# Pandemonium

Standard setup for the [Pandemonium](https://github.com/calvin-mcd/Pandemonium/) 30% keyboard.

## Board Revision and Layout Notes

This Pandemonium implementation is for...

- rev 1.1 of the board
